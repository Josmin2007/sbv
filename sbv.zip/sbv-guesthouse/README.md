# SBV Guesthouse - Site Web

Site web professionnel pour SBV Guesthouse basée à Parakou, Bénin.

## 📋 Fonctionnalités

### Interface Utilisateur
- ✅ Page de connexion et d'inscription
- ✅ Navbar avec navigation (Accueil | Mes réservations | À propos)
- ✅ Menu utilisateur avec nom et déconnexion
- ✅ Affichage des chambres disponibles avec 4 catégories
- ✅ Gestion des réservations personnelles
- ✅ Page À propos avec informations complètes

### Interface Administrateur
- ✅ Dashboard avec statistiques en temps réel
- ✅ Graphiques de suivi (occupation, types de chambres)
- ✅ Gestion complète des chambres (ajout, modification, suppression)
- ✅ Gestion des réservations avec acceptation/refus
- ✅ Activités récentes

## 🏠 Types de Chambres

1. **Entré Couché** - 15 000 FCFA/nuit
2. **1 Chambre Salon** - 25 000 FCFA/nuit
3. **2 Chambres Salon** - 35 000 FCFA/nuit
4. **3 Chambres Salon** - 50 000 FCFA/nuit

## 🚀 Installation

### Prérequis
- Un serveur web (Apache, Nginx, etc.)
- Aucune base de données requise (frontend seulement)

### Déploiement

1. **Télécharger les fichiers**
   Tous les fichiers sont dans le dossier `sbv-guesthouse/`

2. **Téléverser sur votre hébergeur**
   - Via FTP (FileZilla, etc.)
   - Via cPanel File Manager
   - Via Git si disponible

3. **Structure des fichiers**
   ```
   sbv-guesthouse/
   ├── login.html              (Page de connexion)
   ├── register.html           (Page d'inscription)
   ├── user-index.html         (Accueil utilisateur)
   ├── user-reservations.html  (Réservations utilisateur)
   ├── user-about.html         (À propos)
   ├── admin-dashboard.html    (Dashboard admin)
   ├── admin-rooms.html        (Gestion chambres)
   └── admin-reservations.html (Gestion réservations)
   ```

4. **Accès au site**
   - Page d'accueil : `login.html`
   - Pour tester l'admin : utilisez `admin@sbv.com`
   - Pour tester l'utilisateur : tout autre email

## 🎨 Technologies Utilisées

- **HTML5** - Structure
- **CSS3** - Styles personnalisés
- **Tailwind CSS** - Framework CSS (via CDN)
- **JavaScript** - Interactivité
- **Chart.js** - Graphiques du dashboard
- **Google Fonts** - Typographie (Playfair Display + Poppins)

## 🎨 Design

Le site utilise une palette de couleurs inspirée de l'Afrique :
- Vert principal : `#2C5F2D`
- Or/Doré : `#D4AF37`
- Marron : `#8B4513`

Design moderne avec :
- Animations fluides
- Responsive (mobile, tablette, desktop)
- Interface intuitive
- Composants réutilisables

## 📱 Pages Disponibles

### Utilisateur
1. **login.html** - Connexion
2. **register.html** - Inscription
3. **user-index.html** - Accueil avec chambres
4. **user-reservations.html** - Mes réservations
5. **user-about.html** - À propos

### Administrateur
1. **admin-dashboard.html** - Vue d'ensemble
2. **admin-rooms.html** - Gestion des chambres
3. **admin-reservations.html** - Gestion des réservations

## 🔐 Comptes de Test

### Administrateur
- Email : `admin@sbv.com`
- Mot de passe : (n'importe lequel pour la démo)

### Utilisateur
- Email : n'importe quel email sauf `admin@sbv.com`
- Mot de passe : (n'importe lequel pour la démo)

## 🌐 Hébergement Recommandé

Le site peut être hébergé sur :
- **Hostinger** (recommandé pour le Bénin)
- **000webhost** (gratuit pour commencer)
- **GitHub Pages** (gratuit)
- **Netlify** (gratuit)
- **Vercel** (gratuit)
- Tout hébergeur supportant HTML/CSS/JS

## 📞 Support

Pour toute question ou assistance :
- Email : contact@sbv-guesthouse.com
- Téléphone : +229 XX XX XX XX
- Adresse : Parakou, Bénin

## 📝 Notes Importantes

1. **Backend** : Ce site est actuellement frontend seulement. Pour une version complète avec base de données, il faudra :
   - Ajouter un backend (PHP, Node.js, Python, etc.)
   - Connecter une base de données (MySQL, PostgreSQL, etc.)
   - Implémenter l'authentification réelle
   - Gérer les paiements en ligne

2. **Images** : Les images actuelles sont des placeholders SVG. Remplacez-les par vos vraies photos de chambres.

3. **Personnalisation** : 
   - Modifiez les numéros de téléphone
   - Ajoutez votre vraie adresse
   - Mettez à jour les prix selon vos tarifs
   - Ajoutez vos propres images

## 🔄 Prochaines Étapes

Pour rendre le site pleinement fonctionnel :

1. **Backend & Base de données**
   - Système de réservation réel
   - Gestion des utilisateurs
   - Paiement en ligne (MTN Mobile Money, Moov Money, etc.)

2. **Fonctionnalités additionnelles**
   - Calendrier de disponibilité
   - Galerie photos
   - Avis clients
   - Système de newsletter
   - Multi-langues (FR/EN)

3. **SEO & Marketing**
   - Optimisation pour Google
   - Intégration Google Maps
   - Meta tags
   - Sitemap

## 📜 Licence

© 2024 SBV Guesthouse. Tous droits réservés.

---

**Développé avec ❤️ pour SBV Guesthouse, Parakou**
